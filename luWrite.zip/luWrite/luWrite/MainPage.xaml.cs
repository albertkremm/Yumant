﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.Storage.AccessCache;
using Windows.Storage.Pickers;
using Windows.UI;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Input;
using Windows.UI.Text;
using Windows.UI.Core;
using Windows.System;

namespace Yumant
{
    public sealed partial class MainPage : Page
    {
        private const string EmbeddedFontName = "iA Writer Mono S";
        private const string EmbeddedFontUri =
            "ms-appx:///Assets/Fonts/iAWriterMonoS-Regular.ttf#iA Writer Mono S";

        private const string LastFileTokenKey = "Yumant_LastOpenedFile";
        private const string LastFileToken = "Yumant_LastDocument";
        private const string DiaryFolderTokenKey = "Yumant_DiaryFolder";
        private const string DiaryFolderToken = "Yumant_DiaryFolderToken";
        private const string BackupFolderName = "Backups";
        private const int MaxBackupsPerFile = 10;
        private const double CalendarPanelWidth = 340;

        private StorageFile currentFile;
        private StorageFolder diaryFolder;

        private DispatcherTimer sentenceFocusTimer;
        private DispatcherTimer clockTimer;

        private bool sentenceFocusEnabled;
        private bool isUpdatingFocus;
        private bool settingsLoaded;
        private bool pageInitialized;
        private bool isDiaryDocument;

        private int previousSentenceStart = -1;
        private int previousSentenceLength = 0;

        private string currentTheme = "Dark";
        private DateTime calendarMonth;

        private readonly Dictionary<string, int> diaryEntries =
            new Dictionary<string, int>();

        private readonly List<string> availableFonts =
            new List<string>
            {
                EmbeddedFontName,
                "Segoe UI",
                "Arial",
                "Calibri",
                "Cambria",
                "Consolas",
                "Courier New",
                "Georgia",
                "Tahoma",
                "Times New Roman",
                "Verdana"
            };

        public MainPage()
        {
            InitializeComponent();

            InitializeFonts();
            InitializeTimers();

            EditorTextBox.Document.SetText(
                TextSetOptions.None,
                ""
            );

            calendarMonth = new DateTime(
                DateTime.Today.Year,
                DateTime.Today.Month,
                1
            );

            UpdateWordCount();
            UpdateClock();

            Window.Current.CoreWindow.KeyDown += CoreWindow_KeyDown;
        }

        // =========================================================
        // ГОРЯЧИЕ КЛАВИШИ
        // =========================================================

        private async void CoreWindow_KeyDown(
            CoreWindow sender,
            KeyEventArgs args)
        {
            if (args.VirtualKey == VirtualKey.S &&
                (sender.GetKeyState(VirtualKey.Control) &
                 CoreVirtualKeyStates.Down) ==
                 CoreVirtualKeyStates.Down)
            {
                args.Handled = true;
                await SaveCurrentDocumentAsync();
            }
        }

        // =========================================================
        // СКРЫТИЕ ПАНЕЛЕЙ
        // =========================================================

        private void EditorTextBox_GotFocus(
            object sender,
            RoutedEventArgs e)
        {
            HidePanels();
        }

        private void EditorTextBox_Tapped(
            object sender,
            TappedRoutedEventArgs e)
        {
            HidePanels();
        }

        private void HidePanels()
        {
            // Календарь здесь намеренно не закрываем.
            // Он закрывается только повторным нажатием кнопки календаря.

            SettingsPanel.Visibility = Visibility.Collapsed;

            if (EditorCommandBar != null)
            {
                EditorCommandBar.IsOpen = false;
            }
        }

        // =========================================================
        // ИНИЦИАЛИЗАЦИЯ
        // =========================================================

        private void InitializeFonts()
        {
            FontFamilyComboBox.Items.Clear();

            foreach (string fontName in availableFonts)
            {
                FontFamilyComboBox.Items.Add(fontName);
            }

            FontFamilyComboBox.SelectedItem = EmbeddedFontName;
        }

        private void InitializeTimers()
        {
            sentenceFocusTimer = new DispatcherTimer();
            sentenceFocusTimer.Interval = TimeSpan.FromMilliseconds(180);
            sentenceFocusTimer.Tick += SentenceFocusTimer_Tick;

            clockTimer = new DispatcherTimer();
            clockTimer.Interval = TimeSpan.FromSeconds(1);
            clockTimer.Tick += ClockTimer_Tick;
            clockTimer.Start();
        }

        private async void MainPage_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            if (pageInitialized)
            {
                return;
            }

            pageInitialized = true;

            RestoreSettings();
            settingsLoaded = true;

            await RestoreDiaryFolderAsync();
            await RestoreLastFileAsync();

            SaveAllSettings();

            if (currentFile == null)
            {
                StatusText.Text = "Готово";
            }
        }

        // =========================================================
        // НАСТРОЙКИ
        // =========================================================

        private void SaveSetting(string key, object value)
        {
            try
            {
                ApplicationData.Current.LocalSettings.Values[key] = value;
            }
            catch
            {
            }
        }

        private object ReadSetting(string key)
        {
            try
            {
                return ApplicationData.Current.LocalSettings.Values[key];
            }
            catch
            {
                return null;
            }
        }

        private string ReadStringSetting(
            string key,
            string defaultValue)
        {
            object value = ReadSetting(key);
            return value == null ? defaultValue : value.ToString();
        }

        private double ReadDoubleSetting(
            string key,
            double defaultValue)
        {
            object value = ReadSetting(key);

            if (value == null)
            {
                return defaultValue;
            }

            try
            {
                return Convert.ToDouble(value);
            }
            catch
            {
                return defaultValue;
            }
        }

        private bool ReadBooleanSetting(
            string key,
            bool defaultValue)
        {
            object value = ReadSetting(key);

            if (value == null)
            {
                return defaultValue;
            }

            try
            {
                return Convert.ToBoolean(value);
            }
            catch
            {
                return defaultValue;
            }
        }

        private void SaveAllSettings()
        {
            if (!settingsLoaded)
            {
                return;
            }

            if (FontFamilyComboBox.SelectedItem != null)
            {
                SaveSetting(
                    "SelectedFont",
                    FontFamilyComboBox.SelectedItem.ToString()
                );
            }

            SaveSetting("FontSize", FontSizeSlider.Value);
            SaveSetting("EditorWidth", EditorWidthSlider.Value);
            SaveSetting("Theme", currentTheme);
            SaveSetting("SentenceFocusEnabled", sentenceFocusEnabled);
        }

        private void RestoreSettings()
        {
            settingsLoaded = false;

            string fontName = ReadStringSetting(
                "SelectedFont",
                EmbeddedFontName
            );

            if (!FontFamilyComboBox.Items.Contains(fontName))
            {
                fontName = EmbeddedFontName;
            }

            FontFamilyComboBox.SelectedItem = fontName;
            ApplySelectedFont(fontName);

            double fontSize = ReadDoubleSetting("FontSize", 14);

            fontSize = Math.Max(
                FontSizeSlider.Minimum,
                Math.Min(FontSizeSlider.Maximum, fontSize)
            );

            FontSizeSlider.Value = fontSize;
            EditorTextBox.FontSize = fontSize;
            FontSizeValueText.Text = ((int)fontSize).ToString();

            double editorWidth = ReadDoubleSetting("EditorWidth", 760);

            editorWidth = Math.Max(
                EditorWidthSlider.Minimum,
                Math.Min(EditorWidthSlider.Maximum, editorWidth)
            );

            EditorWidthSlider.Value = editorWidth;
            EditorContainer.Width = editorWidth;
            EditorWidthValueText.Text = ((int)editorWidth).ToString() + " px";

            currentTheme = ReadStringSetting("Theme", "Dark");

            if (currentTheme == "Light")
            {
                ThemeComboBox.SelectedIndex = 1;
                ApplyLightTheme();
            }
            else
            {
                currentTheme = "Dark";
                ThemeComboBox.SelectedIndex = 0;
                ApplyDarkTheme();
            }

            sentenceFocusEnabled = ReadBooleanSetting(
                "SentenceFocusEnabled",
                false
            );

            if (sentenceFocusEnabled)
            {
                sentenceFocusTimer.Start();
            }
            else
            {
                sentenceFocusTimer.Stop();
            }

            previousSentenceStart = -1;
            previousSentenceLength = 0;
        }

        // =========================================================
        // ВЫБОР ПАПКИ ДНЕВНИКА
        // =========================================================

        private async void ChooseDiaryFolderButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            FolderPicker picker = new FolderPicker();
            picker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
            picker.FileTypeFilter.Add("*");

            StorageFolder selectedFolder =
                await picker.PickSingleFolderAsync();

            if (selectedFolder == null)
            {
                return;
            }

            string errorMessage = null;

            try
            {
                StorageApplicationPermissions.FutureAccessList.AddOrReplace(
                    DiaryFolderToken,
                    selectedFolder
                );

                SaveSetting(DiaryFolderTokenKey, DiaryFolderToken);

                diaryFolder = selectedFolder;
                DiaryFolderText.Text = selectedFolder.Name;
                StatusText.Text = "Папка дневника: " + selectedFolder.Name;

                await ScanDiaryFolderAsync();

                if (CalendarPanel.Visibility == Visibility.Visible)
                {
                    BuildCalendar();
                }
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Не удалось сохранить папку дневника:\n" + ex.Message;
            }

            if (errorMessage != null)
            {
                MessageDialog dialog = new MessageDialog(errorMessage);
                await dialog.ShowAsync();
            }
        }

        private async Task RestoreDiaryFolderAsync()
        {
            string token = ReadStringSetting(DiaryFolderTokenKey, "");

            if (String.IsNullOrEmpty(token))
            {
                DiaryFolderText.Text = "Не выбрана";
                return;
            }

            try
            {
                diaryFolder =
                    await StorageApplicationPermissions.FutureAccessList.GetFolderAsync(token);

                DiaryFolderText.Text = diaryFolder.Name;

                await ScanDiaryFolderAsync();
            }
            catch
            {
                diaryFolder = null;
                DiaryFolderText.Text = "Папка недоступна";
                diaryEntries.Clear();
            }
        }

        // =========================================================
        // СКАНИРОВАНИЕ ДНЕВНИКА
        // =========================================================

        private async Task<List<StorageFile>>
            GetDiaryFilesRecursiveAsync(StorageFolder folder)
        {
            List<StorageFile> result = new List<StorageFile>();

            if (folder == null)
            {
                return result;
            }

            IReadOnlyList<StorageFile> files = await folder.GetFilesAsync();

            foreach (StorageFile file in files)
            {
                string extension = file.FileType.ToLowerInvariant();

                if (extension == ".md" ||
                    extension == ".txt" ||
                    extension == ".markdown")
                {
                    result.Add(file);
                }
            }

            IReadOnlyList<StorageFolder> folders = await folder.GetFoldersAsync();

            foreach (StorageFolder child in folders)
            {
                try
                {
                    List<StorageFile> childFiles =
                        await GetDiaryFilesRecursiveAsync(child);

                    result.AddRange(childFiles);
                }
                catch
                {
                }
            }

            return result;
        }

        private string GetDateKey(DateTime date)
        {
            return date.ToString("yyyy-MM-dd");
        }

        private bool TryGetDateFromDiaryFile(
            StorageFile file,
            out DateTime date)
        {
            date = DateTime.MinValue;

            string nameWithoutExtension =
                System.IO.Path.GetFileNameWithoutExtension(file.Name);

            Match match = Regex.Match(
                nameWithoutExtension,
                @"^(\d{4}-\d{2}-\d{2})$"
            );

            if (!match.Success)
            {
                return false;
            }

            return DateTime.TryParseExact(
                match.Groups[1].Value,
                "yyyy-MM-dd",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None,
                out date
            );
        }

        private async Task ScanDiaryFolderAsync()
        {
            if (diaryFolder == null)
            {
                diaryEntries.Clear();
                return;
            }

            string errorMessage = null;

            try
            {
                diaryEntries.Clear();

                List<StorageFile> files =
                    await GetDiaryFilesRecursiveAsync(diaryFolder);

                foreach (StorageFile file in files)
                {
                    DateTime date;

                    if (!TryGetDateFromDiaryFile(file, out date))
                    {
                        continue;
                    }

                    int wordCount = await GetWordCountForFileAsync(file);

                    diaryEntries[GetDateKey(date)] = wordCount;
                }

                StatusText.Text =
                    "Дневник: найдено " + diaryEntries.Count.ToString() + " записей";
            }
            catch (Exception ex)
            {
                StatusText.Text = "Ошибка сканирования дневника";

                errorMessage =
                    "Не удалось просканировать дневник:\n" + ex.Message;
            }

            if (errorMessage != null)
            {
                MessageDialog dialog = new MessageDialog(errorMessage);
                await dialog.ShowAsync();
            }
        }

        // =========================================================
        // ОТКРЫТИЕ ЗАМЕТКИ ДНЕВНИКА
        // =========================================================

        private string GetDiaryFileName(DateTime date)
        {
            return date.ToString("yyyy-MM-dd") + ".md";
        }

        private async Task<StorageFile> FindDiaryFileAsync(DateTime date)
        {
            if (diaryFolder == null)
            {
                return null;
            }

            string expectedName = GetDiaryFileName(date);

            List<StorageFile> files =
                await GetDiaryFilesRecursiveAsync(diaryFolder);

            foreach (StorageFile file in files)
            {
                if (String.Equals(
                    file.Name,
                    expectedName,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return file;
                }
            }

            string dateName = date.ToString("yyyy-MM-dd");

            foreach (StorageFile file in files)
            {
                string nameWithoutExtension =
                    System.IO.Path.GetFileNameWithoutExtension(file.Name);

                if (String.Equals(
                    nameWithoutExtension,
                    dateName,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return file;
                }
            }

            return null;
        }

        private async Task<StorageFile> GetOrCreateDiaryFileAsync(DateTime date)
        {
            if (diaryFolder == null)
            {
                return null;
            }

            StorageFile file = await FindDiaryFileAsync(date);

            if (file != null)
            {
                return file;
            }

            return await diaryFolder.CreateFileAsync(
                GetDiaryFileName(date),
                CreationCollisionOption.OpenIfExists
            );
        }

        private async Task OpenDiaryDateAsync(DateTime date)
        {
            if (diaryFolder == null)
            {
                MessageDialog dialog = new MessageDialog(
                    "Сначала выбери папку дневника в настройках."
                );

                await dialog.ShowAsync();

                SettingsPanel.Visibility = Visibility.Visible;

                // Календарь не закрываем.
                return;
            }

            string errorMessage = null;

            try
            {
                StorageFile file = await GetOrCreateDiaryFileAsync(date);

                if (file == null)
                {
                    return;
                }

                string text = await FileIO.ReadTextAsync(file);

                EditorTextBox.Document.SetText(TextSetOptions.None, text);

                currentFile = file;
                isDiaryDocument = true;

                RememberCurrentFile(file);

                previousSentenceStart = -1;
                previousSentenceLength = 0;

                UpdateWordCount();

                if (sentenceFocusEnabled)
                {
                    ApplyNormalColorToWholeDocument();
                    UpdateSentenceFocus();
                }

                // Календарь остаётся открытым.
                EditorContainer.Visibility = Visibility.Visible;

                StatusText.Text = "Дневник: " + date.ToString("yyyy-MM-dd");
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Не удалось открыть заметку дневника:\n" + ex.Message;
            }

            if (errorMessage != null)
            {
                MessageDialog dialog = new MessageDialog(errorMessage);
                await dialog.ShowAsync();
            }
        }

        private async void DailyNotesButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            await OpenDiaryDateAsync(DateTime.Today);
        }

        // =========================================================
        // КАЛЕНДАРЬ
        // =========================================================

        private async void CalendarButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            SettingsPanel.Visibility = Visibility.Collapsed;

            EditorContainer.Visibility = Visibility.Visible;

            // Если календарь уже открыт — закрываем его.
            if (CalendarPanel.Visibility == Visibility.Visible)
            {
                CalendarPanel.Visibility = Visibility.Collapsed;
                CalendarColumn.Width = new GridLength(0);
                return;
            }

            // Если закрыт — открываем.
            CalendarColumn.Width =
                new GridLength(CalendarPanelWidth);

            CalendarPanel.Visibility = Visibility.Visible;

            calendarMonth = new DateTime(
                DateTime.Today.Year,
                DateTime.Today.Month,
                1
            );

            await ScanDiaryFolderAsync();

            BuildCalendar();
        }

        private void CalendarPreviousButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            calendarMonth = calendarMonth.AddMonths(-1);
            BuildCalendar();
        }

        private void CalendarNextButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            calendarMonth = calendarMonth.AddMonths(1);
            BuildCalendar();
        }

        private void CalendarTodayButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            calendarMonth = new DateTime(
                DateTime.Today.Year,
                DateTime.Today.Month,
                1
            );

            BuildCalendar();
        }

        private async void CalendarDay_Click(
            object sender,
            RoutedEventArgs e)
        {
            Button button = sender as Button;

            if (button == null || button.Tag == null)
            {
                return;
            }

            DateTime date;

            if (DateTime.TryParseExact(
                button.Tag.ToString(),
                "yyyy-MM-dd",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None,
                out date))
            {
                await OpenDiaryDateAsync(date);
            }
        }

        private async Task<int> GetWordCountForFileAsync(StorageFile file)
        {
            try
            {
                string text = await FileIO.ReadTextAsync(file);
                string trimmed = text.Trim();

                if (trimmed.Length == 0)
                {
                    return 0;
                }

                return Regex.Split(trimmed, @"\s+").Length;
            }
            catch
            {
                return 0;
            }
        }

        private int GetDiaryDotCount(DateTime date)
        {
            int wordCount;

            if (!diaryEntries.TryGetValue(GetDateKey(date), out wordCount))
            {
                return 0;
            }

            if (wordCount > 300)
            {
                return 3;
            }

            if (wordCount > 200)
            {
                return 2;
            }

            return 1;
        }

        // Создаёт один месяц календаря.
        // Заголовок каждого месяца отображается непосредственно над сеткой.
        private void BuildMonth(DateTime month, bool isCenterMonth)
        {
            StackPanel monthPanel = new StackPanel();
            monthPanel.Margin = new Thickness(0, 8, 0, 12);

            // Название месяца.
            TextBlock monthTitle = new TextBlock();
            monthTitle.Text = month.ToString("MMMM yyyy");
            monthTitle.FontSize = isCenterMonth ? 17 : 15;
            monthTitle.FontWeight = isCenterMonth
                ? Windows.UI.Text.FontWeights.SemiBold
                : Windows.UI.Text.FontWeights.Normal;

            monthTitle.HorizontalAlignment = HorizontalAlignment.Center;
            monthTitle.Margin = new Thickness(0, 0, 0, 8);

            monthTitle.Foreground = new SolidColorBrush(
                isCenterMonth
                    ? Color.FromArgb(255, 120, 170, 230)
                    : Color.FromArgb(255, 175, 181, 190)
            );

            monthPanel.Children.Add(monthTitle);

            // Заголовки дней недели.
            Grid weekdayGrid = new Grid();

            for (int i = 0; i < 7; i++)
            {
                weekdayGrid.ColumnDefinitions.Add(new ColumnDefinition());
            }

            string[] weekdays =
            {
                "Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"
            };

            for (int i = 0; i < 7; i++)
            {
                TextBlock weekday = new TextBlock();
                weekday.Text = weekdays[i];
                weekday.FontSize = 12;
                weekday.HorizontalAlignment = HorizontalAlignment.Center;

                weekday.Foreground = new SolidColorBrush(
                    Color.FromArgb(255, 140, 146, 155)
                );

                Grid.SetColumn(weekday, i);
                weekdayGrid.Children.Add(weekday);
            }

            monthPanel.Children.Add(weekdayGrid);

            // Сетка дней.
            Grid dayGrid = new Grid();

            for (int i = 0; i < 7; i++)
            {
                dayGrid.ColumnDefinitions.Add(new ColumnDefinition());
            }

            int daysInMonth = DateTime.DaysInMonth(
                month.Year,
                month.Month
            );

            int firstDay = ((int)month.DayOfWeek + 6) % 7;

            int totalCells = firstDay + daysInMonth;
            int rows = (totalCells + 6) / 7;

            for (int i = 0; i < rows; i++)
            {
                dayGrid.RowDefinitions.Add(
                    new RowDefinition
                    {
                        Height = new GridLength(43)
                    }
                );
            }

            for (int day = 1; day <= daysInMonth; day++)
            {
                DateTime date = new DateTime(
                    month.Year,
                    month.Month,
                    day
                );

                int index = firstDay + day - 1;
                int row = index / 7;
                int column = index % 7;

                StackPanel dayContent = new StackPanel();
                dayContent.HorizontalAlignment =
                    HorizontalAlignment.Center;

                dayContent.VerticalAlignment =
                    VerticalAlignment.Center;

                TextBlock dayText = new TextBlock();
                dayText.Text = day.ToString();
                dayText.FontSize = 14;
                dayText.HorizontalAlignment =
                    HorizontalAlignment.Center;

                dayText.Foreground = new SolidColorBrush(
                    Color.FromArgb(255, 236, 236, 236)
                );

                dayContent.Children.Add(dayText);

                int dotCount = GetDiaryDotCount(date);

                if (dotCount > 0)
                {
                    TextBlock dots = new TextBlock();
                    dots.Text = new string('●', dotCount);
                    dots.FontSize = 8;
                    dots.HorizontalAlignment =
                        HorizontalAlignment.Center;

                    dots.Foreground = new SolidColorBrush(
                        Color.FromArgb(255, 120, 170, 230)
                    );

                    dayContent.Children.Add(dots);
                }

                Button dayButton = new Button();
                dayButton.Content = dayContent;
                dayButton.Tag = date.ToString("yyyy-MM-dd");
                dayButton.Click += CalendarDay_Click;
                dayButton.Padding = new Thickness(0);
                dayButton.Margin = new Thickness(1);

                dayButton.Background = new SolidColorBrush(
                    Color.FromArgb(255, 32, 35, 41)
                );

                dayButton.BorderThickness = new Thickness(0);

                if (date.Date == DateTime.Today)
                {
                    dayButton.BorderThickness = new Thickness(1);

                    dayButton.BorderBrush = new SolidColorBrush(
                        Color.FromArgb(255, 120, 170, 230)
                    );
                }

                Grid.SetRow(dayButton, row);
                Grid.SetColumn(dayButton, column);

                dayGrid.Children.Add(dayButton);
            }

            monthPanel.Children.Add(dayGrid);
            CalendarMonthsPanel.Children.Add(monthPanel);
        }

        // Строит три месяца:
        // предыдущий — текущий — следующий.
        private void BuildCalendar()
        {
            CalendarMonthsPanel.Children.Clear();

            // В верхнем заголовке панели показываем центральный месяц.
         
            DateTime previousMonth = calendarMonth.AddMonths(-1);
            DateTime nextMonth = calendarMonth.AddMonths(1);

            BuildMonth(previousMonth, false);
            BuildMonth(calendarMonth, true);
            BuildMonth(nextMonth, false);
        }

        // =========================================================
        // ПОСЛЕДНИЙ ОТКРЫТЫЙ ФАЙЛ
        // =========================================================

        private void RememberCurrentFile(StorageFile file)
        {
            if (file == null)
            {
                return;
            }

            try
            {
                StorageApplicationPermissions.FutureAccessList.AddOrReplace(
                    LastFileToken,
                    file
                );

                SaveSetting(LastFileTokenKey, LastFileToken);
            }
            catch
            {
            }
        }

        private async Task RestoreLastFileAsync()
        {
            string token = ReadStringSetting(LastFileTokenKey, "");

            if (String.IsNullOrEmpty(token))
            {
                return;
            }

            try
            {
                StorageFile file =
                    await StorageApplicationPermissions.FutureAccessList.GetFileAsync(token);

                string text = await FileIO.ReadTextAsync(file);

                EditorTextBox.Document.SetText(TextSetOptions.None, text);

                currentFile = file;

                isDiaryDocument =
                    file.Name.Length >= 10 &&
                    Regex.IsMatch(file.Name, @"^\d{4}-\d{2}-\d{2}");

                UpdateWordCount();

                if (sentenceFocusEnabled)
                {
                    ApplyNormalColorToWholeDocument();
                    UpdateSentenceFocus();
                }

                StatusText.Text = "Восстановлен: " + file.Name;
            }
            catch
            {
                StatusText.Text = "Последний документ недоступен";
            }
        }

        // =========================================================
        // РЕЗЕРВНЫЕ КОПИИ
        // =========================================================

        private async Task<string> CreateBackupAsync()
        {
            if (currentFile == null)
            {
                return null;
            }

            var properties = await currentFile.GetBasicPropertiesAsync();

            if (properties.Size == 0)
            {
                return null;
            }

            StorageFolder backupFolder =
                await ApplicationData.Current.LocalFolder.CreateFolderAsync(
                    BackupFolderName,
                    CreationCollisionOption.OpenIfExists
                );

            string backupName =
                currentFile.Name + "." +
                DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") +
                ".bak";

            StorageFile backupFile =
                await currentFile.CopyAsync(
                    backupFolder,
                    backupName,
                    NameCollisionOption.GenerateUniqueName
                );

            try
            {
                IReadOnlyList<StorageFile> files =
                    await backupFolder.GetFilesAsync();

                List<StorageFile> backups = new List<StorageFile>();
                string prefix = currentFile.Name + ".";

                foreach (StorageFile file in files)
                {
                    if (file.Name.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        backups.Add(file);
                    }
                }

                backups.Sort(
                    delegate(StorageFile a, StorageFile b)
                    {
                        return b.DateCreated.CompareTo(a.DateCreated);
                    }
                );

                for (int i = MaxBackupsPerFile; i < backups.Count; i++)
                {
                    try
                    {
                        await backups[i].DeleteAsync();
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return backupFile.Name;
        }

        // =========================================================
        // СОХРАНЕНИЕ
        // =========================================================

        private async void SaveButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            await SaveCurrentDocumentAsync();
        }

        private async void SaveAsButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            await SaveAsAsync();
        }

        private async Task SaveCurrentDocumentAsync()
        {
            if (currentFile == null)
            {
                await SaveAsAsync();
                return;
            }

            await SaveToCurrentFileAsync();
        }

        private async Task SaveAsAsync()
        {
            FileSavePicker picker = new FileSavePicker();
            picker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;

            picker.FileTypeChoices.Add(
                "Markdown",
                new List<string> { ".md" }
            );

            picker.FileTypeChoices.Add(
                "Текстовый файл",
                new List<string> { ".txt" }
            );

            picker.SuggestedFileName = "Новая заметка";

            StorageFile file = await picker.PickSaveFileAsync();

            if (file == null)
            {
                return;
            }

            currentFile = file;
            isDiaryDocument = false;

            await SaveToCurrentFileAsync();
        }

        private async Task SaveToCurrentFileAsync()
        {
            if (currentFile == null)
            {
                return;
            }

            string text;
            EditorTextBox.Document.GetText(TextGetOptions.None, out text);

            string errorMessage = null;
            string backupName = null;

            try
            {
                backupName = await CreateBackupAsync();

                await FileIO.WriteTextAsync(currentFile, text);

                RememberCurrentFile(currentFile);

                StatusText.Text =
                    backupName == null
                        ? "Сохранено: " + currentFile.Name
                        : "Сохранено. Копия: " + backupName;

                if (isDiaryDocument)
                {
                    DateTime diaryDate;

                    if (DateTime.TryParseExact(
                        System.IO.Path.GetFileNameWithoutExtension(currentFile.Name),
                        "yyyy-MM-dd",
                        System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None,
                        out diaryDate))
                    {
                        diaryEntries[GetDateKey(diaryDate)] =
                            Regex.Split(text.Trim(), @"\s+").Length;

                        if (text.Trim().Length == 0)
                        {
                            diaryEntries[GetDateKey(diaryDate)] = 0;
                        }

                        if (CalendarPanel.Visibility == Visibility.Visible)
                        {
                            BuildCalendar();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Не удалось сохранить файл:\n" + ex.Message;
            }

            if (errorMessage != null)
            {
                MessageDialog dialog = new MessageDialog(errorMessage);
                await dialog.ShowAsync();
            }
        }

        // =========================================================
        // ОТКРЫТИЕ ФАЙЛОВ
        // =========================================================

        private async void OpenButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            FileOpenPicker picker = new FileOpenPicker();
            picker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;

            picker.FileTypeFilter.Add(".md");
            picker.FileTypeFilter.Add(".txt");
            picker.FileTypeFilter.Add(".markdown");

            StorageFile file = await picker.PickSingleFileAsync();

            if (file == null)
            {
                return;
            }

            string errorMessage = null;

            try
            {
                string text = await FileIO.ReadTextAsync(file);

                EditorTextBox.Document.SetText(TextSetOptions.None, text);

                currentFile = file;
                isDiaryDocument = false;

                RememberCurrentFile(file);
                UpdateWordCount();

                if (sentenceFocusEnabled)
                {
                    ApplyNormalColorToWholeDocument();
                    UpdateSentenceFocus();
                }

                StatusText.Text = "Открыт: " + file.Name;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Не удалось открыть файл:\n" + ex.Message;
            }

            if (errorMessage != null)
            {
                MessageDialog dialog = new MessageDialog(errorMessage);
                await dialog.ShowAsync();
            }
        }

        private void NewButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            EditorTextBox.Document.SetText(TextSetOptions.None, "");

            currentFile = null;
            isDiaryDocument = false;

            previousSentenceStart = -1;
            previousSentenceLength = 0;

            UpdateWordCount();
            StatusText.Text = "Новый документ";
        }

        // =========================================================
        // РЕДАКТОР
        // =========================================================

        private void EditorTextBox_TextChanged(
            object sender,
            RoutedEventArgs e)
        {
            // Не закрываем календарь при вводе текста.
            // Скрываем только настройки и нижнюю панель.
            SettingsPanel.Visibility = Visibility.Collapsed;

            if (EditorCommandBar != null)
            {
                EditorCommandBar.IsOpen = false;
            }

            UpdateWordCount();

            if (sentenceFocusEnabled)
            {
                sentenceFocusTimer.Stop();
                sentenceFocusTimer.Start();
            }

            StatusText.Text = "Изменено";
        }

        private void EditorTextBox_SelectionChanged(
            object sender,
            RoutedEventArgs e)
        {
            if (sentenceFocusEnabled)
            {
                sentenceFocusTimer.Stop();
                sentenceFocusTimer.Start();
            }
        }

        // =========================================================
        // SENTENCE FOCUS
        // =========================================================

        private void SentenceFocusButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            sentenceFocusEnabled = !sentenceFocusEnabled;

            if (sentenceFocusEnabled)
            {
                previousSentenceStart = -1;
                previousSentenceLength = 0;

                ApplyNormalColorToWholeDocument();
                sentenceFocusTimer.Start();

                StatusText.Text = "Sentence Focus включён";
                UpdateSentenceFocus();
            }
            else
            {
                sentenceFocusTimer.Stop();
                RestoreEditorFormatting();

                StatusText.Text = "Sentence Focus выключен";
            }

            SaveAllSettings();
        }

        private void SentenceFocusTimer_Tick(
            object sender,
            object e)
        {
            if (!sentenceFocusEnabled || isUpdatingFocus)
            {
                return;
            }

            UpdateSentenceFocus();
        }

        private Color GetNormalTextColor()
        {
            if (currentTheme == "Light")
            {
                return Color.FromArgb(255, 176, 176, 176);
            }

            return Color.FromArgb(255, 104, 109, 117);
        }

        private Color GetFocusTextColor()
        {
            if (currentTheme == "Light")
            {
                return Color.FromArgb(255, 30, 30, 30);
            }

            return Color.FromArgb(255, 255, 255, 255);
        }

        private void ApplyNormalColorToWholeDocument()
        {
            string text;
            EditorTextBox.Document.GetText(TextGetOptions.None, out text);

            if (text.Length == 0)
            {
                return;
            }

            ITextRange range =
                EditorTextBox.Document.GetRange(0, text.Length);

            range.CharacterFormat.ForegroundColor = GetNormalTextColor();
        }

        private void UpdateSentenceFocus()
        {
            string text;
            EditorTextBox.Document.GetText(TextGetOptions.None, out text);

            if (String.IsNullOrEmpty(text))
            {
                return;
            }

            int selectionStart =
                EditorTextBox.Document.Selection.StartPosition;

            selectionStart = Math.Max(
                0,
                Math.Min(text.Length, selectionStart)
            );

            int start = selectionStart;
            int end = selectionStart;

            while (start > 0)
            {
                char c = text[start - 1];

                if (c == '.' || c == '!' || c == '?' || c == '\n')
                {
                    break;
                }

                start--;
            }

            while (end < text.Length)
            {
                char c = text[end];

                if (c == '.' || c == '!' || c == '?' || c == '\n')
                {
                    end++;
                    break;
                }

                end++;
            }

            int length = end - start;

            if (length <= 0)
            {
                return;
            }

            if (start == previousSentenceStart &&
                length == previousSentenceLength)
            {
                return;
            }

            isUpdatingFocus = true;

            try
            {
                if (previousSentenceStart >= 0 &&
                    previousSentenceLength > 0)
                {
                    ITextRange oldRange =
                        EditorTextBox.Document.GetRange(
                            previousSentenceStart,
                            previousSentenceStart + previousSentenceLength
                        );

                    oldRange.CharacterFormat.ForegroundColor =
                        GetNormalTextColor();
                }

                ITextRange currentRange =
                    EditorTextBox.Document.GetRange(start, end);

                currentRange.CharacterFormat.ForegroundColor =
                    GetFocusTextColor();

                previousSentenceStart = start;
                previousSentenceLength = length;
            }
            catch
            {
            }
            finally
            {
                isUpdatingFocus = false;
            }
        }

        private void RestoreEditorFormatting()
        {
            string text;
            EditorTextBox.Document.GetText(TextGetOptions.None, out text);

            if (text.Length > 0)
            {
                ITextRange range =
                    EditorTextBox.Document.GetRange(0, text.Length);

                range.CharacterFormat.ForegroundColor =
                    currentTheme == "Light"
                        ? Color.FromArgb(255, 30, 30, 30)
                        : Color.FromArgb(255, 236, 236, 236);
            }

            previousSentenceStart = -1;
            previousSentenceLength = 0;
        }

        // =========================================================
        // СЧЁТЧИК СЛОВ
        // =========================================================

        private void UpdateWordCount()
        {
            string text;
            EditorTextBox.Document.GetText(TextGetOptions.None, out text);

            string trimmed = text.Trim();
            int count = 0;

            if (trimmed.Length > 0)
            {
                count = Regex.Split(trimmed, @"\s+").Length;
            }

            WordCountText.Text = "Слов: " + count.ToString();
        }

        // =========================================================
        // НАСТРОЙКИ
        // =========================================================

        private void SettingsButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            SettingsPanel.Visibility =
                SettingsPanel.Visibility == Visibility.Visible
                    ? Visibility.Collapsed
                    : Visibility.Visible;
        }

        private void CloseSettingsButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            SettingsPanel.Visibility = Visibility.Collapsed;
        }

        private void FontFamilyComboBox_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (FontFamilyComboBox.SelectedItem == null)
            {
                return;
            }

            ApplySelectedFont(FontFamilyComboBox.SelectedItem.ToString());
            SaveAllSettings();
        }

        private void ApplySelectedFont(string fontName)
        {
            if (fontName == EmbeddedFontName)
            {
                EditorTextBox.FontFamily = new FontFamily(EmbeddedFontUri);
            }
            else
            {
                EditorTextBox.FontFamily = new FontFamily(fontName);
            }
        }

        private void FontSizeSlider_ValueChanged(
            object sender,
            RangeBaseValueChangedEventArgs e)
        {
            if (EditorTextBox == null || FontSizeValueText == null)
            {
                return;
            }

            EditorTextBox.FontSize = e.NewValue;
            FontSizeValueText.Text = ((int)e.NewValue).ToString();

            SaveAllSettings();
        }

        private void EditorWidthSlider_ValueChanged(
            object sender,
            RangeBaseValueChangedEventArgs e)
        {
            if (EditorContainer == null || EditorWidthValueText == null)
            {
                return;
            }

            EditorContainer.Width = e.NewValue;
            EditorWidthValueText.Text = ((int)e.NewValue).ToString() + " px";

            SaveAllSettings();
        }

        private void ThemeComboBox_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (ThemeComboBox.SelectedItem == null)
            {
                return;
            }

            ComboBoxItem item =
                ThemeComboBox.SelectedItem as ComboBoxItem;

            if (item == null)
            {
                return;
            }

            if (item.Content.ToString() == "Светлая")
            {
                ApplyLightTheme();
            }
            else
            {
                ApplyDarkTheme();
            }

            SaveAllSettings();
        }

        private void ApplyDarkTheme()
        {
            currentTheme = "Dark";

            Color background = Color.FromArgb(255, 23, 25, 29);
            Color primary = Color.FromArgb(255, 236, 236, 236);
            Color secondary = Color.FromArgb(255, 191, 197, 206);

            EditorTextBox.Background = new SolidColorBrush(background);
            EditorTextBox.Foreground = new SolidColorBrush(primary);

            TopBarGrid.Background = new SolidColorBrush(background);
            StatusBarGrid.Background = new SolidColorBrush(background);

            DeviceInfoText.Foreground = new SolidColorBrush(secondary);
            StatusText.Foreground = new SolidColorBrush(secondary);
            WordCountText.Foreground = new SolidColorBrush(secondary);

            if (sentenceFocusEnabled)
            {
                ApplyNormalColorToWholeDocument();

                previousSentenceStart = -1;
                previousSentenceLength = 0;

                UpdateSentenceFocus();
            }
            else
            {
                RestoreEditorFormatting();
            }
        }

        private void ApplyLightTheme()
        {
            currentTheme = "Light";

            Color background = Color.FromArgb(255, 245, 245, 245);
            Color primary = Color.FromArgb(255, 30, 30, 30);
            Color secondary = Color.FromArgb(255, 85, 85, 85);

            EditorTextBox.Background = new SolidColorBrush(background);
            EditorTextBox.Foreground = new SolidColorBrush(primary);

            TopBarGrid.Background = new SolidColorBrush(background);
            StatusBarGrid.Background = new SolidColorBrush(background);

            DeviceInfoText.Foreground = new SolidColorBrush(secondary);
            StatusText.Foreground = new SolidColorBrush(secondary);
            WordCountText.Foreground = new SolidColorBrush(secondary);

            if (sentenceFocusEnabled)
            {
                ApplyNormalColorToWholeDocument();

                previousSentenceStart = -1;
                previousSentenceLength = 0;

                UpdateSentenceFocus();
            }
            else
            {
                RestoreEditorFormatting();
            }
        }

        // =========================================================
        // ВРЕМЯ
        // =========================================================

        private void ClockTimer_Tick(object sender, object e)
        {
            UpdateClock();
        }

        private void UpdateClock()
        {
            DeviceInfoText.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
        }

        // =========================================================
        // НЕДАВНИЕ ФАЙЛЫ И ПРОЕКТЫ
        // =========================================================

        private async void RecentButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            MessageDialog dialog = new MessageDialog(
                "История недавно открытых файлов пока не реализована."
            );

            await dialog.ShowAsync();
        }

        private async void ProjectsButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            MessageDialog dialog = new MessageDialog(
                "Раздел проектов пока не реализован."
            );

            await dialog.ShowAsync();
        }
    }
}