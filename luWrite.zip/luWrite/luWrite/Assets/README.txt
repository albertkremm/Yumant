Yumant — Windows 8.1 assets

Logo.png        150 x 150
SmallLogo.png    30 x 30
WideLogo.png    310 x 150
StoreLogo.png    50 x 50
SplashScreen.png 620 x 300

PNG, RGBA. WideLogo.png is intended for the Windows 8.1 wide tile.
Add the files to the project's Assets folder and assign them in Package.appxmanifest.
